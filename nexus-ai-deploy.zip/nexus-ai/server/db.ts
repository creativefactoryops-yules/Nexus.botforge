// server/db.ts
// Drizzle database connection + query helpers
// Uncomment and configure when you add a real database

import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import { eq, desc, and, like } from 'drizzle-orm';
import * as schema from '../schema';

// ── Connection ─────────────────────────────────────────────────────────────
// Uncomment when DATABASE_URL is configured:
/*
const connection = await mysql.createConnection(process.env.DATABASE_URL!);
export const db = drizzle(connection, { schema, mode: 'default' });
*/

// Placeholder export so imports don't break before DB is connected
export const db = null as any;

// ── Task helpers ───────────────────────────────────────────────────────────

export async function getTasksByUser(userId: string) {
  return db
    .select()
    .from(schema.tasks)
    .where(eq(schema.tasks.userId, userId))
    .orderBy(desc(schema.tasks.createdAt));
}

export async function createTask(data: typeof schema.tasks.$inferInsert) {
  const result = await db.insert(schema.tasks).values(data);
  return result;
}

export async function updateTask(
  id: string,
  userId: string,
  data: Partial<typeof schema.tasks.$inferInsert>
) {
  return db
    .update(schema.tasks)
    .set({ ...data, updatedAt: new Date() })
    .where(and(eq(schema.tasks.id, id), eq(schema.tasks.userId, userId)));
}

export async function deleteTask(id: string, userId: string) {
  return db
    .delete(schema.tasks)
    .where(and(eq(schema.tasks.id, id), eq(schema.tasks.userId, userId)));
}

export async function getTaskStats(userId: string) {
  const tasks = await getTasksByUser(userId);
  return {
    total:      tasks.length,
    inProgress: tasks.filter(t => t.status === 'in_progress').length,
    completed:  tasks.filter(t => t.status === 'completed').length,
    pending:    tasks.filter(t => t.status === 'pending').length,
    totalTime:  tasks.reduce((s, t) => s + (Number(t.timeEstimate) || 0), 0),
  };
}

// ── Memory bank helpers ────────────────────────────────────────────────────

export async function getMemoryByUser(userId: string, search?: string) {
  const query = db
    .select()
    .from(schema.memoryBank)
    .where(
      search
        ? and(eq(schema.memoryBank.userId, userId), like(schema.memoryBank.key, `%${search}%`))
        : eq(schema.memoryBank.userId, userId)
    )
    .orderBy(desc(schema.memoryBank.updatedAt));

  return query;
}

export async function upsertMemory(userId: string, key: string, value: string) {
  return db
    .insert(schema.memoryBank)
    .values({ userId, key, value })
    .onDuplicateKeyUpdate({ set: { value, updatedAt: new Date() } });
}

export async function deleteMemory(userId: string, key: string) {
  return db
    .delete(schema.memoryBank)
    .where(and(eq(schema.memoryBank.userId, userId), eq(schema.memoryBank.key, key)));
}

// ── Command history helpers ────────────────────────────────────────────────

export async function getCommandHistory(userId: string, limit = 20) {
  return db
    .select()
    .from(schema.commandHistory)
    .where(eq(schema.commandHistory.userId, userId))
    .orderBy(desc(schema.commandHistory.createdAt))
    .limit(limit);
}

export async function saveCommand(data: typeof schema.commandHistory.$inferInsert) {
  return db.insert(schema.commandHistory).values(data);
}

// ── User helpers ───────────────────────────────────────────────────────────

export async function getUserById(id: string) {
  const [user] = await db
    .select()
    .from(schema.users)
    .where(eq(schema.users.id, id));
  return user ?? null;
}

export async function updateUserTier(
  userId: string,
  tier: 'free' | 'initiate' | 'execute',
  stripeData?: { customerId?: string; subscriptionId?: string }
) {
  return db
    .update(schema.users)
    .set({
      tier,
      ...(stripeData?.customerId    && { stripeCustomerId:    stripeData.customerId }),
      ...(stripeData?.subscriptionId && { stripeSubscriptionId: stripeData.subscriptionId }),
      updatedAt: new Date(),
    })
    .where(eq(schema.users.id, userId));
}
