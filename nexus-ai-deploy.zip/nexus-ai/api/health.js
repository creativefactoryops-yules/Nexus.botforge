// api/health.js
// GET /api/health — system health check for uptime monitoring

export default async function handler(req, res) {
  const checks = {
    status:    'ok',
    timestamp: new Date().toISOString(),
    version:   '2.0.4',
    services: {
      api:        'ok',
      stripe:     process.env.STRIPE_SECRET_KEY     ? 'configured' : 'missing_key',
      anthropic:  process.env.ANTHROPIC_API_KEY     ? 'configured' : 'missing_key',
      database:   process.env.DATABASE_URL           ? 'configured' : 'not_connected',
      kv:         process.env.KV_REST_API_URL        ? 'configured' : 'using_memory',
    },
  };

  const allOk = checks.services.stripe !== 'missing_key' &&
                checks.services.anthropic !== 'missing_key';

  res.status(allOk ? 200 : 207).json(checks);
}
