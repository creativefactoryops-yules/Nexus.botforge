// api/tasks/index.js
// Task CRUD — GET /api/tasks | POST /api/tasks
// Uses Vercel KV if available, falls back to in-memory (resets on cold start)
// Swap getStore/setStore for your DB when ready

// ── Storage helpers (swap these for Drizzle/DB calls) ──────────────────────
let _memStore = {}; // fallback in-memory store

async function getStore(key) {
  // If Vercel KV is connected:
  if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
    const { kv } = await import('@vercel/kv');
    return await kv.get(key);
  }
  return _memStore[key] ?? null;
}

async function setStore(key, value) {
  if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
    const { kv } = await import('@vercel/kv');
    return await kv.set(key, value);
  }
  _memStore[key] = value;
}

// ── Helpers ────────────────────────────────────────────────────────────────
function uid() {
  return `task_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

function validate(body) {
  if (!body.name || typeof body.name !== 'string') return 'name is required';
  if (body.category && !['personal', 'business', 'other'].includes(body.category)) {
    return 'category must be personal, business, or other';
  }
  return null;
}

// ── Handler ────────────────────────────────────────────────────────────────
export default async function handler(req, res) {
  // In production, derive userId from auth session/token
  // For now, use a header or default
  const userId = req.headers['x-user-id'] || 'default_user';
  const storeKey = `tasks:${userId}`;

  // ── GET — list all tasks ─────────────────────────────────────────────────
  if (req.method === 'GET') {
    const tasks = (await getStore(storeKey)) || [];
    const { status, category } = req.query;

    let filtered = tasks;
    if (status)   filtered = filtered.filter(t => t.status === status);
    if (category) filtered = filtered.filter(t => t.category === category);

    const stats = {
      total:      tasks.length,
      inProgress: tasks.filter(t => t.status === 'in_progress').length,
      completed:  tasks.filter(t => t.status === 'completed').length,
      pending:    tasks.filter(t => t.status === 'pending').length,
      totalTime:  tasks.reduce((s, t) => s + (Number(t.timeEstimate) || 0), 0),
    };

    return res.status(200).json({ tasks: filtered, stats });
  }

  // ── POST — create a task ─────────────────────────────────────────────────
  if (req.method === 'POST') {
    const error = validate(req.body);
    if (error) return res.status(400).json({ error });

    const tasks = (await getStore(storeKey)) || [];
    const now = new Date().toISOString();

    const task = {
      id:           uid(),
      userId,
      name:         req.body.name.trim(),
      description:  req.body.description?.trim() || '',
      steps:        Array.isArray(req.body.steps) ? req.body.steps : [],
      category:     req.body.category || 'personal',
      timeEstimate: Number(req.body.timeEstimate) || 0,
      status:       'pending',
      createdAt:    now,
      updatedAt:    now,
    };

    tasks.unshift(task);
    await setStore(storeKey, tasks);

    return res.status(201).json({ task });
  }

  res.status(405).json({ error: 'Method not allowed' });
}
