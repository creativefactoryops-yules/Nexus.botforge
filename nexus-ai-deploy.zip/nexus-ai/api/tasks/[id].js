// api/tasks/[id].js
// PATCH /api/tasks/:id  — update status or fields
// DELETE /api/tasks/:id — delete a task

let _memStore = {};

async function getStore(key) {
  if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
    const { kv } = await import('@vercel/kv');
    return await kv.get(key);
  }
  return _memStore[key] ?? null;
}

async function setStore(key, value) {
  if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
    const { kv } = await import('@vercel/kv');
    return await kv.set(key, value);
  }
  _memStore[key] = value;
}

const VALID_STATUSES = ['pending', 'in_progress', 'completed', 'cancelled'];

export default async function handler(req, res) {
  const userId  = req.headers['x-user-id'] || 'default_user';
  const storeKey = `tasks:${userId}`;
  const { id } = req.query;

  const tasks = (await getStore(storeKey)) || [];
  const idx   = tasks.findIndex(t => t.id === id);

  if (idx === -1) {
    return res.status(404).json({ error: `Task ${id} not found` });
  }

  // ── PATCH — update task ────────────────────────────────────────────────
  if (req.method === 'PATCH') {
    const allowed = ['name', 'description', 'steps', 'category', 'timeEstimate', 'status'];
    const updates = {};

    for (const key of allowed) {
      if (req.body[key] !== undefined) updates[key] = req.body[key];
    }

    if (updates.status && !VALID_STATUSES.includes(updates.status)) {
      return res.status(400).json({ error: `status must be one of: ${VALID_STATUSES.join(', ')}` });
    }

    tasks[idx] = { ...tasks[idx], ...updates, updatedAt: new Date().toISOString() };
    await setStore(storeKey, tasks);

    return res.status(200).json({ task: tasks[idx] });
  }

  // ── DELETE — remove task ───────────────────────────────────────────────
  if (req.method === 'DELETE') {
    const [removed] = tasks.splice(idx, 1);
    await setStore(storeKey, tasks);

    return res.status(200).json({ deleted: true, task: removed });
  }

  // ── GET — single task ─────────────────────────────────────────────────
  if (req.method === 'GET') {
    return res.status(200).json({ task: tasks[idx] });
  }

  res.status(405).json({ error: 'Method not allowed' });
}
