// api/memory/index.js
// GET  /api/memory         — list all memory entries
// POST /api/memory         — store a key/value pair
// DELETE /api/memory?key=x — delete a key

let _memStore = {};

async function getStore(key) {
  if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
    const { kv } = await import('@vercel/kv');
    return await kv.get(key);
  }
  return _memStore[key] ?? null;
}

async function setStore(key, value) {
  if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
    const { kv } = await import('@vercel/kv');
    return await kv.set(key, value);
  }
  _memStore[key] = value;
}

export default async function handler(req, res) {
  const userId   = req.headers['x-user-id'] || 'default_user';
  const storeKey = `memory:${userId}`;

  // ── GET — list / recall ──────────────────────────────────────────────────
  if (req.method === 'GET') {
    const bank  = (await getStore(storeKey)) || {};
    const { search } = req.query;

    let entries = Object.entries(bank).map(([key, entry]) => ({ key, ...entry }));

    if (search) {
      const q = search.toLowerCase();
      entries = entries.filter(
        e => e.key.toLowerCase().includes(q) || String(e.value).toLowerCase().includes(q)
      );
    }

    // Sort newest first
    entries.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));

    return res.status(200).json({ memory: entries, count: entries.length });
  }

  // ── POST — store a key/value ─────────────────────────────────────────────
  if (req.method === 'POST') {
    const { key, value } = req.body;

    if (!key || typeof key !== 'string') {
      return res.status(400).json({ error: 'key is required' });
    }
    if (value === undefined || value === null) {
      return res.status(400).json({ error: 'value is required' });
    }
    if (key.length > 200) {
      return res.status(400).json({ error: 'key must be under 200 characters' });
    }

    const bank = (await getStore(storeKey)) || {};
    const now  = new Date().toISOString();

    bank[key] = {
      value,
      createdAt: bank[key]?.createdAt || now,
      updatedAt: now,
    };

    await setStore(storeKey, bank);

    return res.status(201).json({
      stored: true,
      key,
      entry: bank[key],
    });
  }

  // ── DELETE — remove a key ────────────────────────────────────────────────
  if (req.method === 'DELETE') {
    const { key } = req.query;

    if (!key) {
      return res.status(400).json({ error: 'key query param is required' });
    }

    const bank = (await getStore(storeKey)) || {};

    if (!bank[key]) {
      return res.status(404).json({ error: `Key "${key}" not found` });
    }

    delete bank[key];
    await setStore(storeKey, bank);

    return res.status(200).json({ deleted: true, key });
  }

  res.status(405).json({ error: 'Method not allowed' });
}
