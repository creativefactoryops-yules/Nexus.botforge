// api/ai/command.js
// Processes natural language commands via Claude LLM
// POST /api/ai/command  →  { prompt: string }

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { prompt, history = [] } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'prompt is required' });
  }

  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(500).json({ error: 'ANTHROPIC_API_KEY not configured' });
  }

  const SYSTEM = `You are NEXUS, an advanced autonomous AI assistant embedded in a cyberpunk command center.

Your capabilities:
- Execute complex multi-step tasks
- Manage the user's task list and memory bank
- Analyze data and generate reports
- Provide strategic recommendations

Response format:
- Be direct and action-oriented
- Use structured output when listing items
- For tasks created: include a JSON block like {"action":"task_created","task":{...}}
- For memory stored: include {"action":"memory_stored","key":"...","value":"..."}
- Keep responses concise but complete
- Use cyberpunk terminology naturally (neural pathways, data streams, etc.)

Current system status: ONLINE | Uplink: STABLE | Authorization: GRANTED`;

  try {
    const messages = [
      ...history.map(h => ({ role: h.role, content: h.content })),
      { role: 'user', content: prompt }
    ];

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-opus-4-5',
        max_tokens: 1024,
        system: SYSTEM,
        messages,
      }),
    });

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.error?.message || 'Anthropic API error');
    }

    const data = await response.json();
    const text = data.content?.map(c => c.text || '').join('') || '';

    // Parse any embedded action JSON
    let action = null;
    const actionMatch = text.match(/\{\"action\":[^}]+\}/);
    if (actionMatch) {
      try { action = JSON.parse(actionMatch[0]); } catch (_) {}
    }

    res.status(200).json({
      response: text,
      action,
      usage: data.usage,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    console.error('AI command error:', err.message);
    res.status(500).json({ error: err.message });
  }
}
