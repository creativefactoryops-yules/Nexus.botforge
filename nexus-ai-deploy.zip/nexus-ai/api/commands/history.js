// api/commands/history.js
// GET  /api/commands/history   — list recent command history
// POST /api/commands/history   — save a command to history (called internally)
// DELETE /api/commands/history — clear all history

let _memStore = {};

async function getStore(key) {
  if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
    const { kv } = await import('@vercel/kv');
    return await kv.get(key);
  }
  return _memStore[key] ?? null;
}

async function setStore(key, value) {
  if (process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
    const { kv } = await import('@vercel/kv');
    return await kv.set(key, value);
  }
  _memStore[key] = value;
}

const MAX_HISTORY = 100;

export default async function handler(req, res) {
  const userId   = req.headers['x-user-id'] || 'default_user';
  const storeKey = `cmd_history:${userId}`;

  // ── GET — list history ───────────────────────────────────────────────────
  if (req.method === 'GET') {
    const history = (await getStore(storeKey)) || [];
    const limit   = Math.min(Number(req.query.limit) || 20, 100);

    return res.status(200).json({
      history: history.slice(0, limit),
      total:   history.length,
    });
  }

  // ── POST — record a command ──────────────────────────────────────────────
  if (req.method === 'POST') {
    const { prompt, response, status = 'completed' } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'prompt is required' });
    }

    const history = (await getStore(storeKey)) || [];
    const now = new Date().toISOString();

    const entry = {
      id:        `cmd_${Date.now()}`,
      userId,
      prompt:    prompt.slice(0, 500),
      response:  response ? response.slice(0, 2000) : null,
      status,    // 'completed' | 'error' | 'pending'
      createdAt: now,
    };

    history.unshift(entry);

    // Keep history capped
    if (history.length > MAX_HISTORY) history.length = MAX_HISTORY;

    await setStore(storeKey, history);

    return res.status(201).json({ saved: true, entry });
  }

  // ── DELETE — clear history ───────────────────────────────────────────────
  if (req.method === 'DELETE') {
    await setStore(storeKey, []);
    return res.status(200).json({ cleared: true });
  }

  res.status(405).json({ error: 'Method not allowed' });
}
