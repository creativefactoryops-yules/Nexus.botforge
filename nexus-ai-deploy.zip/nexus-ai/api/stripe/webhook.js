// api/stripe/webhook.js
// Stripe webhook handler — receives post-payment events from Stripe
// Place at: api/stripe/webhook.js

import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2024-04-10',
});

// Disable body parsing so we get the raw body for signature verification
export const config = { api: { bodyParser: false } };

async function getRawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (chunk) => chunks.push(chunk));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const rawBody = await getRawBody(req);
  const signature = req.headers['stripe-signature'];

  let event;
  try {
    event = stripe.webhooks.constructEvent(
      rawBody,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).json({ error: `Webhook Error: ${err.message}` });
  }

  // Handle events
  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object;
      const tier = session.metadata?.tier;
      const customerId = session.customer;
      const subscriptionId = session.subscription;

      console.log(`✅ New subscription: tier=${tier}, customer=${customerId}, sub=${subscriptionId}`);

      // TODO: Update your database here
      // Example with Drizzle (uncomment when DB is connected):
      // await db.update(users)
      //   .set({ tier, stripeCustomerId: customerId, stripeSubId: subscriptionId })
      //   .where(eq(users.email, session.customer_email));
      break;
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object;
      console.log(`❌ Payment failed for customer: ${invoice.customer}`);
      // TODO: Send failure email, flag account
      break;
    }

    case 'customer.subscription.deleted': {
      const sub = event.data.object;
      console.log(`🚫 Subscription cancelled: ${sub.id}`);
      // TODO: Downgrade user to free tier in DB
      break;
    }

    case 'customer.subscription.updated': {
      const sub = event.data.object;
      console.log(`🔄 Subscription updated: ${sub.id}, status=${sub.status}`);
      break;
    }

    default:
      console.log(`Unhandled event type: ${event.type}`);
  }

  res.status(200).json({ received: true });
}
