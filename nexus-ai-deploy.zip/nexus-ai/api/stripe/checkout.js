// api/stripe/checkout.js
// Simple Stripe checkout handler — works as a Vercel Serverless Function
// Place at: api/stripe/checkout.js

import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2024-04-10',
});

// Your actual Stripe Price IDs
const PRICES = {
  initiate: process.env.STRIPE_PRICE_INITIATE || 'price_1TMSjz2N6gfdKnyg1WSedvqp',
  execute:  process.env.STRIPE_PRICE_EXECUTE  || 'price_1TMSmn2N6gfdKnygnF0IFy5z',
};

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { tier } = req.body;

  if (!PRICES[tier]) {
    return res.status(400).json({ error: `Invalid tier: ${tier}. Must be "initiate" or "execute".` });
  }

  try {
    const session = await stripe.checkout.sessions.create({
      line_items: [{ price: PRICES[tier], quantity: 1 }],
      mode: 'subscription',
      success_url: `${process.env.NEXT_PUBLIC_APP_URL || 'https://your-domain.vercel.app'}/?paid=true&tier=${tier}`,
      cancel_url:  `${process.env.NEXT_PUBLIC_APP_URL || 'https://your-domain.vercel.app'}/#pricing`,
      metadata: { tier },
    });

    res.status(200).json({ url: session.url });
  } catch (err) {
    console.error('Stripe error:', err.message);
    res.status(500).json({ error: err.message });
  }
}
