// drizzle.config.ts
// Run: npx drizzle-kit push  (to apply schema to your DB)
// Run: npx drizzle-kit studio (to browse your DB in a UI)

import type { Config } from 'drizzle-kit';

export default {
  schema:    './schema.ts',
  out:       './drizzle',
  dialect:   'mysql',        // Change to 'postgresql' if using Neon/Supabase
  dbCredentials: {
    url: process.env.DATABASE_URL!,
  },
  verbose: true,
  strict:  true,
} satisfies Config;
